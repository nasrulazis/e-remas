package ilham;
import java.util.Scanner;


public class Ilham {

    private static Scanner inputsuhu;

    public static void main(String args[]) {
        System.out.print("Suhu dalam derajat celcius = ");
        inputsuhu = new Scanner(System.in);
        int suhu = inputsuhu.nextInt();
        if (suhu > 100) {
            System.out.println("Wujud air gas");
        } else if (suhu >= 0 && suhu <= 100) {
            System.out.println("Wujud air cair");
        } else {
            System.out.println("Wujud air beku");
        }
    }
}
